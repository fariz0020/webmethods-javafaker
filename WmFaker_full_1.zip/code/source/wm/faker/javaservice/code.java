package wm.faker.javaservice;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Locale;
import com.github.javafaker.Faker;
// --- <<IS-END-IMPORTS>> ---

public final class code

{
	// ---( internal utility methods )---

	final static code _instance = new code();

	static code _newInstance() { return new code(); }

	static code _cast(Object o) { return (code)o; }

	// ---( server methods )---




	public static final void getAsin (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getAsin)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.code().asin();
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getEan13 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getEan13)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.code().ean13();
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getEan8 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getEan8)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.code().ean8();
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getImei (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getImei)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.code().imei();
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getIsbn10 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getIsbn10)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required useSeparator
		// [o] field:0:required value
		// pipeline	
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			String	useSeparator = IDataUtil.getString( pipelineCursor, "useSeparator" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.code().isbn10();
			if (useSeparator!=null||useSeparator=="true")
				value = faker.code().isbn10(true);
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getIsbn13 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getIsbn13)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required useSeparator
		// [o] field:0:required value
		// pipeline	
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			String	useSeparator = IDataUtil.getString( pipelineCursor, "useSeparator" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.code().isbn13();
			if (useSeparator!=null||useSeparator=="true")
				value = faker.code().isbn13(true);
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

