package wm.faker.javaservice;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Locale;
import com.github.javafaker.Faker;
// --- <<IS-END-IMPORTS>> ---

public final class commerce

{
	// ---( internal utility methods )---

	final static commerce _instance = new commerce();

	static commerce _newInstance() { return new commerce(); }

	static commerce _cast(Object o) { return (commerce)o; }

	// ---( server methods )---




	public static final void getColor (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getColor)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.commerce().color();
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getDepartment (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDepartment)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.commerce().department();
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getMaterial (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getMaterial)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.commerce().material();
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getPrice (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPrice)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required min
		// [i] field:0:required max
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String	min = IDataUtil.getString( pipelineCursor, "min" );
			String	max = IDataUtil.getString( pipelineCursor, "max" );
		
			String value = faker.commerce().price();
			if (min!=null&&max!=null) 
				value = faker.commerce().price(Double.parseDouble(min), Double.parseDouble(max));
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getProductName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getProductName)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.commerce().productName();
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getPromotionCode (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPromotionCode)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required digits
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String	digits = IDataUtil.getString( pipelineCursor, "digits" );
			String value = faker.commerce().promotionCode();
			if (digits!=null)
				value = faker.commerce().promotionCode(Integer.parseInt(digits));
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

