package wm.faker.javaservice;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Locale;
import com.github.javafaker.CreditCardType;
import com.github.javafaker.Faker;
// --- <<IS-END-IMPORTS>> ---

public final class finance

{
	// ---( internal utility methods )---

	final static finance _instance = new finance();

	static finance _newInstance() { return new finance(); }

	static finance _cast(Object o) { return (finance)o; }

	// ---( server methods )---




	public static final void getBic (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getBic)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null) 
				faker = new Faker(new Locale(locale));
			String value = faker.finance().bic();
		pipelineCursor.destroy(); 
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getCreditCard (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCreditCard)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required creditCardType {"AMERICAN_EXPRESS","DANKORT","DINERS_CLUB","DISCOVER","FORBUGSFORENINGEN","JCB","LASER","MASTERCARD","SOLO","SWITCH","VISA",""}
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null) 
				faker = new Faker(new Locale(locale));
		
			String value = faker.finance().creditCard();
			String	creditCardType = IDataUtil.getString( pipelineCursor, "creditCardType" );
			if (creditCardType!=null) {
				if (creditCardType.equals("AMERICAN_EXPRESS")) 
					value = faker.finance().creditCard(CreditCardType.AMERICAN_EXPRESS);
				if (creditCardType.equals("DANKORT")) 
					value = faker.finance().creditCard(CreditCardType.DANKORT);
				if (creditCardType.equals("DINERS_CLUB")) 
					value = faker.finance().creditCard(CreditCardType.DINERS_CLUB);
				if (creditCardType.equals("DISCOVER")) 
					value = faker.finance().creditCard(CreditCardType.DISCOVER);
				if (creditCardType.equals("FORBRUGSFORENINGEN")) 
					value = faker.finance().creditCard(CreditCardType.FORBRUGSFORENINGEN);
				if (creditCardType.equals("LASER")) 
					value = faker.finance().creditCard(CreditCardType.LASER);
				if (creditCardType.equals("SOLO")) 
					value = faker.finance().creditCard(CreditCardType.SOLO);
				if (creditCardType.equals("SWITCH")) 
					value = faker.finance().creditCard(CreditCardType.SWITCH);
				if (creditCardType.equals("JCB")) 
					value = faker.finance().creditCard(CreditCardType.JCB);
				if (creditCardType.equals("MASTERCARD")) 
					value = faker.finance().creditCard(CreditCardType.MASTERCARD);
				if (creditCardType.equals("VISA")) 
					value = faker.finance().creditCard(CreditCardType.VISA);
			}
			
		pipelineCursor.destroy(); 
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getIban (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getIban)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required countryCode
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null) 
				faker = new Faker(new Locale(locale));
			String	countryCode = IDataUtil.getString( pipelineCursor, "countryCode" );
			String value = (countryCode!=null)?faker.finance().iban(countryCode):faker.finance().iban();
		pipelineCursor.destroy(); 
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

