package wm.faker.javaservice;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Locale;
import com.github.javafaker.Faker;
import com.github.javafaker.Internet;
// --- <<IS-END-IMPORTS>> ---

public final class internet

{
	// ---( internal utility methods )---

	final static internet _instance = new internet();

	static internet _newInstance() { return new internet(); }

	static internet _cast(Object o) { return (internet)o; }

	// ---( server methods )---




	public static final void getAvatar (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getAvatar)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().avatar();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getDomainName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDomainName)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().domainName();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getDomainWord (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDomainWord)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().domainWord();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getDomanSuffix (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDomanSuffix)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().domainSuffix();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getEmailAddress (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getEmailAddress)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required localPart
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String	localPart = IDataUtil.getString( pipelineCursor, "localPart" );
			String value = (localPart==null)?faker.internet().emailAddress():faker.internet().emailAddress(localPart);
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getImage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getImage)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required width
		// [i] field:0:required height
		// [i] field:0:required gray {"false","true"}
		// [i] field:0:required text
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			
			Integer	width = IDataUtil.getInt( pipelineCursor, "width", 0);
			Integer	height = IDataUtil.getInt( pipelineCursor, "height", 0);
			Boolean gray = IDataUtil.getBoolean(pipelineCursor, "gray");
			String	text = IDataUtil.getString( pipelineCursor, "text" );
		
			String value = faker.internet().image();
			if (width!=null&&height!=null&&gray!=null&&text!=null)
				value = faker.internet().image(width, height, gray, text);
				
		pipelineCursor.destroy();
		 
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getIpV4Address (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getIpV4Address)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().ipV4Address();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getIpV4Cidr (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getIpV4Cidr)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().ipV4Cidr();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getIpV6Address (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getIpV6Address)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().ipV6Address();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getIpV6Cidr (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getIpV6Cidr)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().ipV6Cidr();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getMacAddress (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getMacAddress)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required prefix
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
		
			String	prefix = IDataUtil.getString( pipelineCursor, "prefix" );
			String value = (prefix==null)?faker.internet().macAddress():faker.internet().macAddress(prefix);
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getPassword (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPassword)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:optional minimumLength
		// [i] field:0:optional maximumLength
		// [i] field:0:optional includeUppercase {"false","true"}
		// [i] field:0:optional includeSpecial {"false","true"}
		// [i] field:0:optional includeDigit {"false","true"}
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().password();
			
			Integer	minimumLength = IDataUtil.getInt( pipelineCursor, "minimumLength", 0 );
			Integer	maximumLength = IDataUtil.getInt( pipelineCursor, "maximumLength", 0 );
			Boolean includeUppercase = IDataUtil.getBoolean(pipelineCursor, "includeUppercase", false);
			Boolean includeSpecial = IDataUtil.getBoolean(pipelineCursor, "includeSpecial", false);
			Boolean includeDigit = IDataUtil.getBoolean(pipelineCursor, "includeDigit", false);
			
			if (minimumLength!=0&&maximumLength!=0&&includeUppercase&&includeSpecial&&includeDigit)
				value = faker.internet().password(minimumLength, maximumLength, includeUppercase, includeSpecial, includeDigit);
		
			if (minimumLength!=0&&maximumLength!=0&&includeUppercase&&includeSpecial)
				value = faker.internet().password(minimumLength, maximumLength, includeUppercase, includeSpecial);
		
			if (minimumLength!=0&&maximumLength!=0&&includeUppercase)
				value = faker.internet().password(minimumLength, maximumLength, includeUppercase);
		
			if (minimumLength!=0&&maximumLength!=0)
				value = faker.internet().password(minimumLength, maximumLength);
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getPrivateIpV4Address (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPrivateIpV4Address)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().privateIpV4Address();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getPublicIpV4Address (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPublicIpV4Address)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().publicIpV4Address();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getSafeEmailAddress (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSafeEmailAddress)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required localPart
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String	localPart = IDataUtil.getString( pipelineCursor, "localPart" );
			String value = (localPart==null)?faker.internet().safeEmailAddress():faker.internet().safeEmailAddress(localPart);
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getSlug (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSlug)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().slug();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getUrl (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getUrl)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().url();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getUserAgent (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getUserAgent)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required userAgent {"AOL","CHROME","FIREFOX","INTERNET_EXPLORER","NETSCAPE","OPERA","SAFARI"}
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String	userAgent = IDataUtil.getString( pipelineCursor, "userAgent" );
			String value = faker.internet().userAgent(Internet.UserAgent.valueOf(userAgent));
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getUserAgentAny (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getUserAgentAny)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().userAgentAny();
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getUuid (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getUuid)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.internet().uuid();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

