package wm.faker.javaservice;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import com.github.javafaker.Faker;
// --- <<IS-END-IMPORTS>> ---

public final class dateandtime

{
	// ---( internal utility methods )---

	final static dateandtime _instance = new dateandtime();

	static dateandtime _newInstance() { return new dateandtime(); }

	static dateandtime _cast(Object o) { return (dateandtime)o; }

	// ---( server methods )---




	public static final void getBetween (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getBetween)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required from
		// [i] field:0:required to
		// [i] field:0:required pattern
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			java.util.Date value = null;
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			String	from = IDataUtil.getString( pipelineCursor, "from" );
			String	to = IDataUtil.getString( pipelineCursor, "to" );
			String	pattern = IDataUtil.getString( pipelineCursor, "pattern" );
			
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			
			if( (pattern == null) || (pattern.trim().length() == 0) )
				pattern = "yyyy-MM-dd\u2019T\u2019HH:mm:sszzz"; // Use a W3C format as default
		
			if( (from != null) && (to.length() > 0) ) {
				java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(pattern);
				java.util.Date fromDate = sdf.parse(from, new java.text.ParsePosition(0));
				java.util.Date toDate = sdf.parse(to, new java.text.ParsePosition(0));
		
				value = faker.date().between(fromDate, toDate);
			}
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value.toLocaleString() );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getBirthday (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getBirthday)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required min
		// [i] field:0:required max
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.date().birthday().toLocaleString();
			String	min = IDataUtil.getString( pipelineCursor, "min" );
			String	max = IDataUtil.getString( pipelineCursor, "max" );
			if (min!=null&&max!=null)
				value = faker.date().birthday(Integer.parseInt(min),Integer.parseInt(max)).toLocaleString();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getFuture (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFuture)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required atMost
		// [i] field:0:required minimum
		// [i] field:0:required unit {"DAYS","HOURS","MINUTES","SECONDS"}
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			
			TimeUnit timeUnit = TimeUnit.DAYS; 
			String	unit = IDataUtil.getString( pipelineCursor, "unit" );
			if (unit.equals("DAYS"))
				timeUnit=TimeUnit.DAYS;
			if (unit.equals("MINUTES"))
				timeUnit=TimeUnit.MINUTES;
			if (unit.equals("SECONDS"))
				timeUnit=TimeUnit.SECONDS;
				
			String	atMost = IDataUtil.getString( pipelineCursor, "atMost" );
			String value = faker.date().future((atMost!=null)?Integer.valueOf(atMost):0, timeUnit).toString();
			
			String	minimum = IDataUtil.getString( pipelineCursor, "minimum" );
			if(minimum!=null)
				value = faker.date().future((atMost!=null)?Integer.valueOf(atMost):0,Integer.valueOf(minimum), timeUnit).toString();
				
			pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getPast (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPast)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required atMost
		// [i] field:0:required minimum
		// [i] field:0:required unit {"DAYS","HOURS","MINUTES","SECONDS"}
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			
			TimeUnit timeUnit = TimeUnit.DAYS; 
			String	unit = IDataUtil.getString( pipelineCursor, "unit" );
			if (unit.equals("DAYS"))
				timeUnit=TimeUnit.DAYS;
			if (unit.equals("MINUTES"))
				timeUnit=TimeUnit.MINUTES;
			if (unit.equals("SECONDS"))
				timeUnit=TimeUnit.SECONDS;
				
			String	atMost = IDataUtil.getString( pipelineCursor, "atMost" );
			String value = faker.date().past((atMost!=null)?Integer.valueOf(atMost):0, timeUnit).toString();
			
			String	minimum = IDataUtil.getString( pipelineCursor, "minimum" );
			if(minimum!=null)
				value = faker.date().past((atMost!=null)?Integer.valueOf(atMost):0,Integer.valueOf(minimum), timeUnit).toString();
				
			pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

