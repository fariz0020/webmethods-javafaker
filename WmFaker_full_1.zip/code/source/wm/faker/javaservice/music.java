package wm.faker.javaservice;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Locale;
import com.github.javafaker.Faker;
// --- <<IS-END-IMPORTS>> ---

public final class music

{
	// ---( internal utility methods )---

	final static music _instance = new music();

	static music _newInstance() { return new music(); }

	static music _cast(Object o) { return (music)o; }

	// ---( server methods )---




	public static final void getChord (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getChord)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.music().chord();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getGenre (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getGenre)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.music().genre();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getInstrument (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getInstrument)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.music().instrument();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getKey (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getKey)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.music().key();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

