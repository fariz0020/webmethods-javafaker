package wm.faker.javaservice;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Locale;
import com.github.javafaker.Faker;
// --- <<IS-END-IMPORTS>> ---

public final class lorem

{
	// ---( internal utility methods )---

	final static lorem _instance = new lorem();

	static lorem _newInstance() { return new lorem(); }

	static lorem _cast(Object o) { return (lorem)o; }

	// ---( server methods )---




	public static final void getCharacters (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCharacters)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [i] field:0:required includeUppercase
		// [i] field:0:required fixedNumberOfCharacters
		// [i] field:0:required minimumLength
		// [i] field:0:required maximumLength
		// [i] field:0:required includeDigit
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.lorem().characters();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getSentence (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSentence)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.lorem().sentence();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getWord (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getWord)>> ---
		// @sigtype java 3.5
		// [i] field:0:required locale
		// [o] field:0:required value
		// pipeline
		Faker faker = new Faker();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	locale = IDataUtil.getString( pipelineCursor, "locale" );
			if (locale!=null)
				faker = new Faker(new Locale(locale));
			String value = faker.lorem().word();
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

